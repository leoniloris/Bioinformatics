Arquivos:

c�digos
  |
  |__ assets/             # Imagens e pdb's utilizados
  |__ Assignment_II.ipynb # C�digo jupyter notebook para execu�ao.
Assignment_II.ipynb       # Reprodu�ao dos c�digos e coment�rios.
