from cost import RastriginModel, RosenbrockModel, AckleyModel
from plot import plot_states
from pso import PSO
opaopa = 1
