## Requirements
* python3
* pip3

## Installing the module:
```python
pip3 install -e .
```

## Running the module:
```
python3 -m pso --plot --population 30
```
